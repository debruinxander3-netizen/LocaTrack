const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();

async function requireAdmin(request) {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  const snap = await db.collection('users').doc(request.auth.uid).get();
  if (!snap.exists || snap.data().active !== true || snap.data().role !== 'admin') {
    throw new HttpsError('permission-denied', 'Admin access required.');
  }
}

exports.adminCreateUser = onCall(async (request) => {
  await requireAdmin(request);
  const { email, password, displayName } = request.data || {};
  if (typeof email !== 'string' || !email.includes('@') ||
      typeof password !== 'string' || password.length < 12 ||
      typeof displayName !== 'string' || !displayName.trim()) {
    throw new HttpsError('invalid-argument', 'Provide a valid email, display name, and password of at least 12 characters.');
  }
  try {
    const user = await getAuth().createUser({ email: email.trim(), password, displayName: displayName.trim(), disabled: false });
    await db.collection('users').doc(user.uid).set({
      email: user.email, displayName: user.displayName, role: 'user', active: true,
      createdAt: FieldValue.serverTimestamp(), createdBy: request.auth.uid
    });
    return { uid: user.uid, email: user.email, displayName: user.displayName, role: 'user' };
  } catch (e) {
    throw new HttpsError('already-exists', e.message || 'Could not create account.');
  }
});

exports.adminSetUserActive = onCall(async (request) => {
  await requireAdmin(request);
  const { uid, active } = request.data || {};
  if (typeof uid !== 'string' || typeof active !== 'boolean') {
    throw new HttpsError('invalid-argument', 'Provide user uid and active true/false.');
  }
  if (uid === request.auth.uid && active === false) {
    throw new HttpsError('failed-precondition', 'Admin cannot deactivate their own account.');
  }
  const ref = db.collection('users').doc(uid);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError('not-found', 'User record not found.');
  await ref.update({ active });
  await getAuth().updateUser(uid, { disabled: !active });
  return { uid, active };
});
