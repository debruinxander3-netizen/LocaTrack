# LocaTrack Cloud — multi-user Android starter

This Android Studio project implements a shared LocaTrack app foundation using Firebase Authentication, Cloud Firestore, Cloud Storage, and trusted Cloud Functions.

## Access model
- Admin: creates/deactivates accounts through a callable Cloud Function; can view shared records and delete any record.
- User: signs in, can view all shared locations/BOLOs, and can add records. A user can edit their own records; only an admin can delete records.
- Cloud rules enforce roles and active status server-side. Do not rely on hiding UI buttons for security.

## Important setup before running
1. Create a Firebase project at https://console.firebase.google.com/.
2. Enable **Authentication > Email/Password**.
3. Create a **Cloud Firestore** database and **Cloud Storage** bucket.
4. Register a Web App in Firebase project settings and copy its config.
5. Open `app/src/main/assets/index.html` and replace the placeholder values in `firebaseConfig` with your Firebase web app config.
6. Install Firebase CLI, run `firebase login`, then from this project folder run `firebase use --add` and select the project.
7. Deploy rules and Functions: `firebase deploy --only firestore:rules,storage,functions`.
8. Bootstrap the first admin once using a trusted one-time setup script or Firebase Console: create the Auth user, then create `users/{that-user-uid}` in Firestore with `{ role: "admin", active: true, email: "...", displayName: "..." }`. Never allow public client-side role creation. Remove/secure any one-time bootstrap script immediately.
9. Open the folder in Android Studio, sync Gradle, and select **Build > Build APK(s)**.

## Cloud behaviour
- Location and BOLO metadata is stored in shared Firestore collections.
- Reference photos are uploaded to Cloud Storage; records store their download URLs.
- Other active users see shared records when they refresh/open the relevant screen.
- This starter uses shared reads and basic write forms. Add production-grade offline queueing, audit logs, pagination, user invitations, and monitoring before operational deployment.

## Security and privacy notes
- Keep Firebase API configuration in the app only as intended for client apps; Firebase API keys are not authorization. Firestore/Storage rules and Auth are the security boundary.
- Never put a service-account private key in the APK or client JavaScript.
- Use truthful, authorised vehicle/location information. BOLO records are user-entered reference data, not automatically verified or transmitted to police.
- Storage rules limit photos to 5 MB and image MIME types. Review data retention, lawful access, and privacy requirements for your organisation.
- This source project is not a compiled APK; it needs Firebase project configuration and an Android Studio build.
