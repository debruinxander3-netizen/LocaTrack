# LocaTrack Android project

LocaTrack is a starter Android app for saving named map locations with reference photos and maintaining a BOLO vehicle list.

## Features
- Map view based on OpenStreetMap tiles (internet required for map tiles).
- Save a custom location name, notes, map coordinates, and a reference photo.
- Browse, view, and delete saved locations.
- Add BOLO vehicle entries with make, model, year, registration, VIN, and photo.
- BOLO entries are marked as records entered by the user; the app does not contact police or broadcast alerts.
- Data is stored locally in the app's browser storage on this device.

## Build an APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync and choose **Build > Build APK(s)**.
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This starter project is not a precompiled APK; it is the source project used to build one.
- Map tiles need an internet connection. Saved records remain on the device, but uninstalling/clearing app data may delete them.
- The app has no cloud sync, login, or shared BOLO distribution in this starter version.
